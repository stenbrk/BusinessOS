# BusinessOS — Deploy op Vercel

## Structuur
```
businessos/
├── api/
│   └── claude.js        ← serverless proxy (API key zit hier, veilig)
├── public/
│   └── index.html       ← de volledige app
├── vercel.json
└── package.json
```

## Deploy in 3 stappen

### 1. Vercel account + CLI
```bash
npm i -g vercel
```
Of ga naar vercel.com en importeer direct via GitHub.

### 2. Zet de API key als environment variable
In Vercel dashboard → jouw project → Settings → Environment Variables:
```
ANTHROPIC_API_KEY = sk-ant-...
```

Of via CLI:
```bash
vercel env add ANTHROPIC_API_KEY
```

### 3. Deploy
```bash
cd businessos
vercel --prod
```

Klaar. Vercel geeft je een URL zoals `businessos-abc123.vercel.app`.
Klanten openen die URL — geen key, geen installatie, AI werkt direct.

## Hoe het werkt
- Browser stuurt AI-verzoeken naar `/api/claude` (jouw eigen server)
- De serverless function voegt de geheime API key toe en stuurt door naar Anthropic
- De key is nooit zichtbaar voor de gebruiker
